import pandas as pd
import numpy as np
import matplotlib.pyplot as plts
import seaborn as sns
from sklearn import preprocessing
df=pd.read_csv("/home/lenovo/Downloads/Social_Network_Ads.csv")
print(df)
print(df.isnull())

label_encoder=preprocessing.LabelEncoder()
df['Gender']=label_encoder.fit_transform(df['Gender'])
print(df['Gender'].unique())
print(df)
#ssprint(df.corr())
#x=df.loc[:,EstimatedSalary]

df.isnull().sum()

df.corr()

x= df.loc[:,["Age","EstimatedSalary"]]
print(x)

#y= df.loc[:,["EstimatedSalary"]]
#print(y)

y=df["Purchased"]
y.head()

from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest =train_test_split(x, y, test_size =0.30,random_state = 0)

#Feature scaling as range of estimated salary and age is different
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
xtrain = sc.fit_transform(xtrain)
xtest = sc.fit_transform(xtest)

# import the class
from sklearn.linear_model import LogisticRegression

# instantiate the model (using the default parameters)
logreg = LogisticRegression()

# fit the model with data
logreg.fit(xtrain,ytrain)

y_pred=logreg.predict(xtest)

# import the metrics class

from sklearn.metrics import  precision_score,confusion_matrix,accuracy_score,recall_score

print("accuracy_score:",accuracy_score(ytest, y_pred))

cm= confusion_matrix(ytest, y_pred)
print('Confusion matrix\n\n', cm)
print('\nTrue Positives(TP) = ', cm[0,0])
print('\nTrue Negatives(TN) = ', cm[1,1])
print('\nFalse Positives(FP) = ', cm[0,1])
print('\nFalse Negatives(FN) = ', cm[1,0])

print('Accuracy: %.3f' % accuracy_score(ytest, y_pred))
print('Precision: %.3f' % precision_score(ytest, y_pred))
print('Recall: %.3f' % recall_score(ytest, y_pred))