import numpy as np
import pandas as pd

pd.set_option('display.max_columns',20)
df=pd.read_csv("/home/lenovo/Documents/pritam.csv")

sorted_rscore= sorted(df["Math_Score"])
print(sorted_rscore)

q1 = np.percentile(sorted_rscore, 25)
q3 = np.percentile(sorted_rscore, 75)
print(q1,q3)

IQR = q3-q1

lwr_bound = q1-(1.5*IQR)
upr_bound = q3+(1.5*IQR)
print(lwr_bound, upr_bound)

r_outliers = []

for i in sorted_rscore:
    if(i<lwr_bound or i>upr_bound):
        r_outliers.append(i)
print(r_outliers)

df_stud=df
ninetieth_percentile = np.percentile(df_stud["Math_Score"], 90)
b = np.where(df_stud["Math_Score"]>ninetieth_percentile,
ninetieth_percentile, df_stud["Math_Score"])
print("New array:",b)

df_stud.insert(1,"m score",b,True)
print(df_stud)


col = ["Math_Score"]
df.boxplot(col)

median=np.median(sorted_rscore)
median
print(df)
refined_df=df
refined_df["Math_Score"] = np.where(refined_df["Math_Score"] >upr_bound, median,refined_df["Math_Score"])
print(refined_df)


refined_df["Math_Score"] = np.where(refined_df["Math_Score"] <lwr_bound, median,refined_df["Math_Score"])
print(refined_df)

col = ["Math_Score"]
refined_df.boxplot(col)
print(refined_df.boxplot)