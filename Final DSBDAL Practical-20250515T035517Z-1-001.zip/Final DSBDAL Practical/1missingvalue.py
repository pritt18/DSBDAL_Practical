import pandas as pd
import numpy as np


df1 = {
    'Name': ['George', 'Andrea', 'micheal', 'maggie', 'Ravi', 'Xien', 'Jalpa', 'ferry'],
    'State': ['Arizona', 'Georgia', 'Newyork', 'Indiana', 'Florida', 'California', np.nan, np.nan],
    'Gender': ["M", "F", "M", "F", "M", "M", np.nan, np.nan],
    'Score': [63, 48, 56, 75, np.nan, 77, np.nan, np.nan]
}

df1 = pd.DataFrame(df1, columns=['Name', 'State', 'Gender', 'Score'])
print(df1)

# for each column
print(df1.isnull())
# for each particular row
print(df1.isnull().any())
print(df1.isnull().sum(axis=1))
print(df1.isnull().sum())
print(df1.Gender.isnull().sum())
print(df1.groupby(['Gender'])['Score'].apply(lambda x: x.isnull().sum()))
print(df1.dtypes)
#print(df1['name(cm)'] = df1['petal length(cm)'].astype("int"))
