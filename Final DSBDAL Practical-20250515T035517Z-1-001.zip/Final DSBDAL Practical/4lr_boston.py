import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_boston
boston = load_boston()
#print(boston)
data = pd.DataFrame(boston.data)
print(boston.feature_names)
data.columns = boston.feature_names
#print(data)
print("Nullvalues",data.isnull().sum())
#Feature Values
x = data
# Response Variable
y = boston.target
#print(y)
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size =0.3,random_state = 0)
print(xtrain.shape)
print(xtest.shape)
print(ytrain.shape)
print(ytest.shape)
import sklearn
from sklearn.linear_model import LinearRegression
lm = LinearRegression()
lr_model=lm.fit(xtrain, ytrain)
print("slope",lr_model.coef_[0])
print("intercept",lr_model.intercept_)
y_train_pred = lm.predict(xtrain)
y_test_pred=lm.predict(xtest)
print(y_train_pred.shape)
print(y_test_pred.shape)
df=pd.DataFrame(y_train_pred,ytrain)
df=pd.DataFrame(y_test_pred,ytest)
print(df)
from sklearn.metrics import mean_squared_error, r2_score
mse = mean_squared_error(ytest, y_test_pred)
print("Testing MSE:",mse)
mse = mean_squared_error(y_train_pred,ytrain)
print("Training MSE:",mse)

from sklearn.metrics import mean_squared_error, r2_score
r1 =r2_score(y_train_pred,ytrain)
print("r1",r1)



