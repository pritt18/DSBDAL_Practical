import pandas as pd
import numpy as np
from scipy import stats
pd.set_option('display.max_columns',20)
df=pd.read_csv("/home/lenovo/Documents/pritam.csv")
z=np.abs()