import pandas as pd
df= pd.read_csv("/home/lenovo/Downloads/PlayTennis(1).csv")
print(df)

from sklearn import preprocessing
le = preprocessing.LabelEncoder()

df_encoded = df.apply(le.fit_transform)

x=df_encoded.drop(['Play Tennis'],axis=1)
print(x)

y=df_encoded['Play Tennis']
print(y)

from sklearn.metrics import accuracy_score ,precision_score,recall_score,f1_score
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=0)


gaussian = GaussianNB()
model=gaussian.fit(X_train, y_train)
Y_pred = gaussian.predict(X_test)
accuracy_nb=round(accuracy_score(y_test,Y_pred)* 100, 2)

print(accuracy_nb)

print(model.predict([[1,0,0,1]]))