import numpy as np
import pandas as pd

pd.set_option('display.max_columns',20)
df=pd.read_csv("/home/lenovo/Documents/pritam.csv")

sorted_rscore= sorted(df["Math_Score"])
print(sorted_rscore)

q1 = np.percentile(sorted_rscore, 25)
q3 = np.percentile(sorted_rscore, 75)
print(q1,q3)

IQR = q3-q1

lwr_bound = q1-(1.5*IQR)
upr_bound = q3+(1.5*IQR)
print(lwr_bound, upr_bound)

r_outliers = []

for i in sorted_rscore:
    if(i<lwr_bound or i>upr_bound):
        r_outliers.append(i)
print(r_outliers)
