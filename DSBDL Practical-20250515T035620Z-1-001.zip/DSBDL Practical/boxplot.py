import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
pd.set_option('display.max_columns',20)
df=pd.read_csv("/home/lenovo/Documents/pritam.csv")
data_score=df.drop(columns="Club_Join_Date")
print(data_score)

col=["Math_Score","Reading_Score","Writing_Score","Placement_Score","Placement_offer"]
box_plot=data_score.boxplot(col)
plt.show(box_plot)
print("Outlier using Box_plots")

print(np.where(df['Math Score']>80))
print(np.where(df['Reading_Score']>75))
print(np.where(df['Writing_Score']>30))
print(np.where(df['Placement_Score']>75))
print(np.where(df['Placement_offer']>80))