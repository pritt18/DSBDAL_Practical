import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
pd.set_option('display.max_columns',20)
df=pd.read_csv("/home/lenovo/Documents/pritam.csv")


col=["Placement_Score","Placement_offer"]
sca_plt=plt.scatter(df["Placement_Score"],df["Placement_offer"])

plt.show(sca_plt)