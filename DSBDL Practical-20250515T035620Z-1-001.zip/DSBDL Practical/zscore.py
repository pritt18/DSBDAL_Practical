import numpy as np
import pandas as pd
from scipy import stats

pd.set_option('display.max_columns',20)
df=pd.read_csv("/home/lenovo/Documents/pritam.csv")

z = np.abs(stats.zscore(df["Math_Score"]))
print(z)
threshold = 0.5
sample_outliers = np.where(z <threshold)
sample_outliers
print(sample_outliers)