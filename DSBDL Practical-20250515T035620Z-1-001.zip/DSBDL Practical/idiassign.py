import pandas as pd
from sklearn import preprocessing

csv_url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data'
col_names = ['Sepal_Length', 'Sepal_Width', 'Petal_Length', 'Petal_Width', 'Species']
iris = pd.read_csv(csv_url, names=col_names)
print(iris.head())
print(iris.tail(n=5))
print(iris.index)
print(iris.shape)
print(iris.dtypes)
print(iris.describe())
print(iris.columns.values)
print(iris.describe(include='all'))
print(iris['Sepal_Length'])
print(iris.sort_index(axis=1, ascending=False))
print(iris.sort_values(by="Sepal_Width"))
print(iris.iloc[5])
print(iris[0:3])
print(iris.loc[:, ["Sepal_Width", "Petal_Width"]])
print(iris.iloc[:5, :])
print(iris.iloc[:, :9])
print(iris.iloc[:7, :2])
print(iris.isnull())
print(iris.head())
min_max_scaler = preprocessing.MinMaxScaler()
x = iris.iloc[:, :4]
print(x)
x_scaled = min_max_scaler.fit_transform(x)
df_normalized = pd.DataFrame(x_scaled)
print(df_normalized)
print(iris['Species'].unique())
label_encoder = preprocessing.LabelEncoder()
iris['Species'] = label_encoder.fit_transform(iris['Species'])
print(iris['Species'].unique())
enc = preprocessing.OneHotEncoder()

enc_df = enc.fit_transform(iris[['Species']]).toarray()
en_frame = pd.DataFrame(enc_df)
print(en_frame)
print(iris['Species'].unique())
features_df = iris.drop(columns=['Species'])
df_encode = features_df.join(en_frame)
print(df_encode)
df_encode.rename(columns={0: 'Iris-Setosa', 1: 'Iris-Versicolor', 2: 'Iris-virginica'}, inplace=True)
print(df_encode)

print(iris['Species'].unique())
one_hot_df = pd.get_dummies(iris, prefix="Species", columns=['Species'], drop_first=True)
print(one_hot_df)


